<?php

return [

    'name'              => 'Template',
    'description'       => 'This is my awesome module',

];